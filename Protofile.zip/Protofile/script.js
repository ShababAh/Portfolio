var typed=new Typed(".text",{
    strings: ["Full Stack Developer", ".NET Devloper", "JAVA Devloper"],
    typeSpeed: 100,
    backSpeed: 100,
    backDelay: 1000,
    loop:true
});

